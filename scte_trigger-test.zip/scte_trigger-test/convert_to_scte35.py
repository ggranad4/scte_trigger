import threefive

text = "{'info_section': {'table_id': '0xfc', 'section_syntax_indicator': False, 'private': False, 'reserved': '0x3', 'section_length': 51, 'protocol_version': 0, 'encrypted_packet': False, 'encryption_algorithm': 0, 'pts_adjustment': 0.0, 'cw_index': '0x0', 'tier': '0xfff', 'splice_command_length': 15, 'splice_command_type': 5, 'descriptor_loop_length': 19, 'crc': '0xfc303300'}, 'command': {'name': 'Splice Insert', 'splice_event_id': 8082531, 'splice_event_cancel_indicator': False, 'out_of_network_indicator': False, 'program_splice_flag': True, 'duration_flag': False, 'splice_immediate_flag': False, 'time_specified_flag': True, 'pts_time': 53489.508, 'unique_program_id': 0, 'avail_num': 0, 'avail_expected': 0}}"



import { Component, OnInit } from '@angular/core';

import { KeyNumber } from "../key-value";
import { KeyString } from "../key-value";
import { KeyBool } from "../key-value"
import { KeyStringArray } from "../key-value";
import { KeyNumberArray } from "../key-value"
import { KeyObject } from "../key-value";
import { LoadJsonService } from '../load-json.service';
import { LocalBreak } from "../template_definitions";

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  public config: KeyObject;
  public existingTemplates = <string[]>[];
  constructor(private LoadJsonService: LoadJsonService) {
    // let url = "http://127.0.0.1:8000/config"
    let url = "/assets/config.json"
      this.LoadJsonService.getConfig(url).subscribe(data => {
      this.config = data;
      console.log(this.config)
      for(let i = 3; i < this.config.value.length; i++) {
        this.existingTemplates.push(this.config.value[i].key)
      }
    })
    }

  ngOnInit(): void {
  }
}
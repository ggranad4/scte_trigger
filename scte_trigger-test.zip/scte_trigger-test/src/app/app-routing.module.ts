import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { from } from 'rxjs';

import { DashboardComponent } from './dashboard/dashboard.component';
import { ValidatorComponent } from './validator/validator.component';
import { ConfigurationComponent } from './configuration/configuration.component';
import { ControlComponent } from './control/control.component';

const routes: Routes = [
  { path: 'dashboard', component: DashboardComponent },
  { path: 'validator', component: ValidatorComponent },
  { path: 'configuration', component: ConfigurationComponent },
  { path: 'control', component: ControlComponent },
  
];

@NgModule({
  declarations: [],
  imports: [CommonModule, RouterModule.forRoot(routes), RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
